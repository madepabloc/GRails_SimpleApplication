package test

class List {
	static void main(args){
		def list = [new String('1'),2,3,4]
		list << 5;
		println "${list<<6}"
		
		def list2 = [1, "Mike", 2, "Chris", 3 , new Integer(5), new Double(3.4), Integer.parseInt(list[0])]
		println list2.size()
		println "Lista multiple -> ${list2}"
		
		
		
		def list3 = [10,11,12,13,14,15,16,17,18,19,20]
		
		println "Multiplos de 2 -> ${list3.findAll {it % 2 == 0}}"
		
		
		def list4 = ["Apple", "Basketball", "Championship"]
		println "Longitud de cada elemento -> ${list4} | ${list4*.size()}"
		
		

	}	
}
