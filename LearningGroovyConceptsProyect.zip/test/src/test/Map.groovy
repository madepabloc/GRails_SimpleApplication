package test

import java.io.ObjectInputStream.HandleTable.HandleList;

class Map {

	static main(args) {
		def emptyMap = [:]
		
		//es como una instancia de la clase MAP
		def mapWithValues = [fruit : 'Apple' , veggie : 'Carrot']
		//puedo instanciarla en un objeto que herede de map como hashmap o treemap
		//lo cual puede estar bien para utilizar cierta funcionalidad del api de java util
		HashMap<String, String> hashmap = mapWithValues;
		TreeMap<String, String> treemap = mapWithValues;
		
		def alist = [fruit:'Apple', 'veggie':'Carrot']
		alist['car'] = 'Sedan'
		alist.put('book', 'Novels')
		alist << [pet : 'Dog']
		println alist.values()
		
		
	}

}
