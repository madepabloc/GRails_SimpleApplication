package test

import java.awt.RenderingHints.Key;

//modos de iterar
class Loops {
	static void main(args){
		
		println 'Iteramos n veces la imprimiendo la palabra hola'
		//itera n veces
		def n = 5
		n.times {
			println "hello"
		}
		
		println '-------------------------------------'
		
		
		println 'Iteramos cada elemento de una lista'
		def list = [1, "Hola", 5.4,  new Double(3.7), "Perro"]
		list.each {
			name -> println name 
			
		}
		
		println '-------------------------------------'
		
		
		println 'Imprimimos un rango de numeros'
		(5..8).each {
			number -> println number
		}
		
		println '-------------------------------------'
		
		println "Iteramos un map"
		def map = [fruit:'Apple', veggie:'Carrot', car:'Sedan']
		map.each {
			key,value -> println "${key} = ${value}"
		}
		println '-------------------------------------'
		
		
		
		
	}
}
